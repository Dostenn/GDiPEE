#!/usr/bin/python

import os
import gammu
file_data = open('/home/pi/SMS.txt','r')
Status = file_data.readline()
Status = '"'+Status+'"'
print Status
cmd ="echo "+ Status + "| sudo gammu sendsms TEXT +33681520873"
os.system(cmd)
file_data.close()
