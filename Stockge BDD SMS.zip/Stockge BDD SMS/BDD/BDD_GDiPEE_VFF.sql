-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : jeu. 01 avr. 2021 à 09:23
-- Version du serveur :  10.3.27-MariaDB-0+deb10u1
-- Version de PHP : 7.3.27-1~deb10u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `BDD_GDiPEE`
--

-- --------------------------------------------------------

--
-- Structure de la table `t_historiquealerte`
--

CREATE TABLE `t_historiquealerte` (
  `idt_HistoriqueAlerte` int(11) NOT NULL,
  `DateHeure` timestamp NULL DEFAULT current_timestamp(),
  `TypeAlerte` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `t_ipraspi`
--

CREATE TABLE `t_ipraspi` (
  `id_ipRaspi` int(11) NOT NULL,
  `ip` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `t_lieu`
--

CREATE TABLE `t_lieu` (
  `idLieu` int(11) NOT NULL,
  `NomLieu` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `t_lieu`
--

INSERT INTO `t_lieu` (`idLieu`, `NomLieu`) VALUES
(1, 'Lorient');

-- --------------------------------------------------------

--
-- Structure de la table `t_mesureelectrique`
--

CREATE TABLE `t_mesureelectrique` (
  `idMesureElectrique` int(11) NOT NULL,
  `Mesure` float NOT NULL,
  `TypeMesure` varchar(22) NOT NULL,
  `Date` timestamp NULL DEFAULT current_timestamp(),
  `fk_typeMesure` int(11) NOT NULL,
  `fk_lieu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `t_mesurevent`
--

CREATE TABLE `t_mesurevent` (
  `idMesureVent` int(11) NOT NULL,
  `VitesseVent` float NOT NULL,
  `Orentation(°)` int(11) NOT NULL,
  `Orentation(cardinal)` varchar(2) NOT NULL,
  `fk_lieu` int(11) NOT NULL,
  `DateMesure` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `t_parametrage`
--

CREATE TABLE `t_parametrage` (
  `idt_Parametrage` int(11) NOT NULL,
  `ValeurSeuilVentMax` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `t_personnelle`
--

CREATE TABLE `t_personnelle` (
  `idt_Personnelle` int(11) NOT NULL,
  `Nom` varchar(45) NOT NULL,
  `Prenom` varchar(45) NOT NULL,
  `NumeroTelephone` varchar(15) NOT NULL,
  `PersonnelleGarde` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `t_typemesure`
--

CREATE TABLE `t_typemesure` (
  `idTypeMesure` int(11) NOT NULL,
  `NomTypeMesure` varchar(45) NOT NULL,
  `UniteMesure` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `t_typemesure`
--

INSERT INTO `t_typemesure` (`idTypeMesure`, `NomTypeMesure`, `UniteMesure`) VALUES
(1, 'Volt', 'V');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `t_historiquealerte`
--
ALTER TABLE `t_historiquealerte`
  ADD PRIMARY KEY (`idt_HistoriqueAlerte`);

--
-- Index pour la table `t_ipraspi`
--
ALTER TABLE `t_ipraspi`
  ADD PRIMARY KEY (`id_ipRaspi`);

--
-- Index pour la table `t_lieu`
--
ALTER TABLE `t_lieu`
  ADD PRIMARY KEY (`idLieu`);

--
-- Index pour la table `t_mesureelectrique`
--
ALTER TABLE `t_mesureelectrique`
  ADD PRIMARY KEY (`idMesureElectrique`),
  ADD KEY `fk_typeMesure` (`fk_typeMesure`),
  ADD KEY `fk_lieu` (`fk_lieu`);

--
-- Index pour la table `t_mesurevent`
--
ALTER TABLE `t_mesurevent`
  ADD PRIMARY KEY (`idMesureVent`),
  ADD KEY `fk_lieu` (`fk_lieu`);

--
-- Index pour la table `t_parametrage`
--
ALTER TABLE `t_parametrage`
  ADD PRIMARY KEY (`idt_Parametrage`);

--
-- Index pour la table `t_personnelle`
--
ALTER TABLE `t_personnelle`
  ADD PRIMARY KEY (`idt_Personnelle`);

--
-- Index pour la table `t_typemesure`
--
ALTER TABLE `t_typemesure`
  ADD PRIMARY KEY (`idTypeMesure`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `t_ipraspi`
--
ALTER TABLE `t_ipraspi`
  MODIFY `id_ipRaspi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `t_lieu`
--
ALTER TABLE `t_lieu`
  MODIFY `idLieu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `t_mesureelectrique`
--
ALTER TABLE `t_mesureelectrique`
  MODIFY `idMesureElectrique` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `t_mesurevent`
--
ALTER TABLE `t_mesurevent`
  MODIFY `idMesureVent` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT pour la table `t_parametrage`
--
ALTER TABLE `t_parametrage`
  MODIFY `idt_Parametrage` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `t_personnelle`
--
ALTER TABLE `t_personnelle`
  MODIFY `idt_Personnelle` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `t_typemesure`
--
ALTER TABLE `t_typemesure`
  MODIFY `idTypeMesure` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `t_mesureelectrique`
--
ALTER TABLE `t_mesureelectrique`
  ADD CONSTRAINT `t_MesureElectrique_ibfk_1` FOREIGN KEY (`fk_typeMesure`) REFERENCES `t_typemesure` (`idTypeMesure`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `t_MesureElectrique_ibfk_2` FOREIGN KEY (`fk_lieu`) REFERENCES `t_lieu` (`idLieu`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `t_mesurevent`
--
ALTER TABLE `t_mesurevent`
  ADD CONSTRAINT `t_MesureVent_ibfk_1` FOREIGN KEY (`fk_lieu`) REFERENCES `t_lieu` (`idLieu`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
