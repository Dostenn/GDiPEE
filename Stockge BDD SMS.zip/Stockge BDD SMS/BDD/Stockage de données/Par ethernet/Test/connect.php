<?php
	$mysqli = new mysqli("10.0.200.136", "SNIR", "SNIR", "bdd_gdipee");
	if ($mysqli->connect_errno) {
    	echo "Echec lors de la connexion à MySQL : (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
	}
?>