# -*- coding: utf-8 -*-
import serial						#Communication Serie avec l'Arduino
import mysql.connector				#Pour pouvoir faire des requetes SQL
import os							#Gestion de fichier
import gammu
import time

from gpiozero import OutputDevice

relais = OutputDevice(18)			#Branchement du relais
i = 0
def envoyer_un_message(message, numero):

	print("envoi d'un message en cours")
	cmd = 'echo "'+ message +'"| sudo gammu sendsms TEXT '+ numero
	os.system(cmd)



mydb = mysql.connector.connect(		#Connexion � la base de donn�e
  host="localhost",				# IP RaspSnir : 10.0.200.145 || Ip Rasp Nelson : ieufdl.ddns.net || Ip Rasp4Snir : 10.0.200.138
  user="SNIR",
  password="SNIR",
  database="gdipee_1",
)

mycursor = mydb.cursor()

serialArduino = serial.Serial('/dev/ttyACM0', 9600)	#Initialisation de la liaison s�rie pour recevoir les donn�es

while True:
	
	###############################################
	# Envoyer les donn�es de l'Arduino sur la BDD #
	###############################################
	
	tabVal = serialArduino.readline()
	tabVal = str(tabVal,"utf-8")
	print(tabVal)
	tabVal = tabVal.split()										#Lecture du port s�rie
	
	#print(tabVal)
	sql = "INSERT INTO `measure` (`wind_speed`, `production`, `deg`, `cardinal`, `place`, `datetime`) VALUES ('"+str(tabVal[2])+"', '0', '"+str(tabVal[0])+"', '"+str(tabVal[1])+"', 'Lorient', current_timestamp());"
	mycursor.execute(sql)							#Executer la requ�te SQL
	mydb.commit()

	print(tabVal)

	if mycursor.rowcount >= 0: 	
		print("Requete effectue.")
	elif mycursor.rowcount < 0:
		print("Echec aucune requete n'a ete effectuer.")
		
	print
	


	##############################################
	# Lecture de la valeur de R�ference du frein #
	##############################################

	fichierRef = open("/var/www/html/BTS/assets/ValRef.txt", "r")		#Ouverture du fichier de la valeur reference pour freiner l'�olienne
	print("Valeur de reference dans le fichier : "+ fichierRef.read())

	with open("/var/www/html/BTS/assets/ValRef.txt", "r") as fileid:
		

		

		filesize = os.path.getsize("/var/www/html/BTS/assets/ValRef.txt")

		if filesize == 0:								#Si le fichier est vide mise auto � 80 sinon �gal a la val du site
			limite=10
			print("Aucune valeur rentre, la valeur par defaut est : %d" % limite)
		else:
			limite = int(fileid.read())
			print("Nouvelle limite : %d" % limite)

	print

	##############################
	# Gestion Frein + alerte SMS #
	##############################

	if float(tabVal[2]) > limite:
		print("Vent trop fort ("+tabVal[2]+" km/h), court-circuitage de l'eolienne")
		relais.on()
		print(i)
		envoyer_un_message("Vent trop fort ("+tabVal[2]+" km/h), court-circuitage de l'eolienne", "+33681520873")
		time.sleep(10)	
			
	else:
		relais.off()
		i = 0



	print("----------------------------------------------------------------------") 	#Fin de la boucle


		

	

