<?php
   	include("connect.php");?>

 <?php
   	

	$vitesse=$_GET["vitesseVent"];
	$orientation=$_GET["avggir"];
	$cardinal=$_GET["cardi"];

	$query = "INSERT INTO `t_MesureVent` (`idMesureVent`, `DateMesure`, `VitesseVent`, `Orientation(Deg)`, `Orientation(cardinal)`, `fk_lieu`) VALUES (NULL, current_timestamp(), '".$vitesse."', '".$orientation."', '".$cardinal."', '1')";
   	
   	$mysqli->query($query);
	$mysqli->close();
	echo $query;
	echo "</br>";
	echo $vitesse;
?>